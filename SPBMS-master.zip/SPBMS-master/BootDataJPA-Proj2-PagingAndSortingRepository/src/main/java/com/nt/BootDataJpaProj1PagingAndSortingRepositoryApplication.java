	package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj1PagingAndSortingRepositoryApplication {

	public static void main(String[] args) 
	{
	
		SpringApplication.run(BootDataJpaProj1PagingAndSortingRepositoryApplication.class, args);
	
	}

}
